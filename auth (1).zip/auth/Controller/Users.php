<?php

require_once('../Connection/DB.php');

require_once('../Helpers/Helpers.php');

if(array_key_exists("user", $_GET)) {
    
    if($_SERVER['REQUEST_METHOD'] !== 'GET') {
    
        $response = new Response(false, 405, "Invalid Method");
        $response->send();
        exit();
        
    }
    
    if(!isset($_GET['user'])) {
        
        $response = new Response(false, 401, "Unauthorized Error");
        $response->send();
        exit();
        
    }
    
    $sessionId = trimAndSecure($_GET['sessionId']);
    $sessionId = str_replace("LNSESS", "", $sessionId);
    
    require_once('../Logics/Auth.php');
    
    $searchUserId = trimAndSecure($_GET['user']);
    $searchUserId = str_replace("LNUSR", "", $searchUserId);
    
    $query = "SELECT `user_id`, `user_full_name`, `user_email_id`, `user_mobile_number`, `user_alternate_number`, `user_emergency_number`, `user_whatsapp_number`, `user_dob`, `user_gender`, `user_bio`, `user_branch`, `user_address`, `user_department`, `user_position`, `user_referred_by`, `user_status`, `user_reports_to`, `user_doj`, `user_termination_date`, `user_active`, `user_updated_at`, `user_created_at` FROM `users` WHERE `user_id`='$searchUserId'";
    $query = $db->prepare($query);
    $query->execute();
    
    if($query->rowCount() === 1) {
            
        $returnData = $query->fetch(PDO::FETCH_ASSOC);

        $response = new Response(true, 200, "User Data Fetched Successfully", $returnData);
        $response->send();
        exit();
            
    } else {
        
        $response = new Response(false, 404, "User Not Found");
        $response->send();
        exit();
        
    }
    
}

if(array_key_exists("values", $_GET)) {
    
    if($_SERVER['REQUEST_METHOD'] !== 'GET') {
    
        $response = new Response(false, 405, "Invalid Method");
        $response->send();
        exit();
        
    }
    
    $sessionId = trimAndSecure($_GET['sessionId']);
    $sessionId = str_replace("LNSESS", "", $sessionId);
    
    require_once('../Logics/Auth.php');
    
    $returnData = array();
    
    //Get users
    $query = "SELECT `user_id`, `user_full_name`, `user_active` FROM `users`";
    $query = $db->prepare($query);
    $query->execute();
    $returnData["users"] = $query->fetchAll(PDO::FETCH_ASSOC);
    
    //Get Branches
    $query = "SELECT `branch_id`, `branch_location` FROM `branches`";
    $query = $db->prepare($query);
    $query->execute();
    $returnData["branches"] = $query->fetchAll(PDO::FETCH_ASSOC);
    
    //Get Departments
    $query = "SELECT `department_id`, `department_name` FROM `department`";
    $query = $db->prepare($query);
    $query->execute();
    $returnData["departments"] = $query->fetchAll(PDO::FETCH_ASSOC);
    
    //Get Positions
    $query = "SELECT `position_id`, `position_name`, `position_level` FROM `positions`";
    $query = $db->prepare($query);
    $query->execute();
    $returnData["positions"] = $query->fetchAll(PDO::FETCH_ASSOC);

    $response = new Response(true, 200, "Values Fetched Successfully", $returnData);
    $response->send();
    exit();
    
}

else if(empty($_GET)) {
    
    if($_SERVER['REQUEST_METHOD'] !== 'POST') {
    
        $response = new Response(false, 405, "Invalid Method");
        $response->send();
        exit();
        
    }
    
    if($_SERVER['CONTENT_TYPE'] !== 'application/json') {
    
        $response = new Response(false, 406, "Content-Type Error");
        $response->send();
        exit();
        
    }
  
    $rawPostData = file_get_contents('php://input');

    if(!$jsonData = json_decode($rawPostData)) {
        
        $response = new Response(false, 403, "Data Forbidden");
        $response->send();
        exit();
        
    }

    if(!isset($jsonData->number) || !isset($jsonData->otp)) {
        
        $response = new Response(false, 401, "Unauthorized Error");
        $response->send();
        exit();
        
    }
  
    if(strlen($jsonData->number) !== 10 || strlen($jsonData->otp) !== 6) {
        
        $response = new Response(false, 403, "Incorrect Credentials");
        $response->send();
        exit();
        
    }
        
    $number    = trimAndSecure($jsonData->number);
    $otp       = trimAndSecure($jsonData->otp);
    $latitude  = isset($jsonData->latitude) ? trimAndSecure($jsonData->latitude) : '';
    $longitude = isset($jsonData->longitude) ? trimAndSecure($jsonData->longitude) : '';
    $platform  = isset($jsonData->platform) ? trimAndSecure($jsonData->platform) : '';
  
    try {

        $query = $db->prepare("SELECT * FROM users WHERE user_whatsapp_number = '$number'");
        $query->execute();

        if($query->rowCount() == 0) {
            
            $response = new Response(false, 401, "Incorrect Contact Number");
            $response->send();
            exit();
            
        }

        $row = $query->fetch(PDO::FETCH_ASSOC);

        $returned_id            = $row['user_id'];
        $returned_fullName      = $row['user_full_name'];
        $returned_email         = $row['user_email_id'];
        $returned_otp           = $row['otp'];
        $returned_otpValidity   = $row['otp_validity'];
        $returned_loginAttempts = $row['user_login_attempts'];
        $returned_userActive    = $row['user_active'];

        if($returned_userActive !== 'Y') {
            
            $response = new Response(false, 403, "Incorrect Credentials");
            $response->send();
            exit();
          
        }

        if($returned_loginAttempts >= 3) {
            
            $response = new Response(false, 403, "Too Many Incorrect Passcode");
            $response->send();
            exit();
          
        }
        
        if(!$returned_otp) {
            
            $response = new Response(false, 401, "Kindly Request OTP");
            $response->send();
            exit();
            
        }
        
        if((int)$otp !== (int)$returned_otp) {
            
            $query = $db->prepare("UPDATE users SET user_login_attempts = user_login_attempts + 1, user_updated_at = '$istTime' WHERE user_id = '$returned_id'");
            $query->execute();
            $response = new Response(false, 401, "Incorrect OTP");
            $response->send();
            exit();
            
        }
    
        if(!$returned_otpValidity || $istTime > $returned_otpValidity) {
            
            $response = new Response(false, 401, "OTP Expired");
            $response->send();
            exit();
            
        }
            
        $accessToken        = manualEncryption($returned_id."_".time());
        $refreshToken       = manualEncryption($returned_id."_".time()."_REFRESHTOKEN_");
        $accessTokenExpiry  = date("Y-m-d H:i:s", time() + 43200);
        $refreshTokenExpiry = date("Y-m-d H:i:s", time() + 86400);
        
    } catch(PDOException $e) {
      
        error_log("SQL Error - Login - " . $e->getMessage());
        $response = new Response(false, 500, "(Action:- Login) Sever Error");
        $response->send();
        exit();
        
    }

    try {

        $db->beginTransaction();
        
        $query = $db->prepare("UPDATE users SET user_login_attempts=0, otp=NULL, otp_validity=NULL, user_updated_at='$istTime' WHERE user_id='$returned_id'");
        $query->execute();
        
        $sessionId = time();
        
        $ip = get_client_ip();
        $clientCountry = '';
        $clientRegion  = '';
        $clientCity    = '';
        iPDetails($ip);
        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        $referrer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : "";
        
        $queryDate = array(
            "session_id"           => $sessionId,
            "user_id"              => $returned_id,
            "access_token"         => $accessToken,
            "access_token_expiry"  => $accessTokenExpiry,
            "refresh_token"        => $refreshToken,
            "refresh_token_expiry" => $refreshTokenExpiry,
            "ip"                   => $ip,
            "country"              => $clientCountry,
            "region"               => $clientRegion,
            "city"                 => $clientCity,
            "latitude"             => $latitude,
            "longitude"            => $longitude,
            "user_agent"           => $userAgent,
            "referer"              => $referrer,
            "platform"             => $platform,
            "phone_number"         => $number,
            "session_started_at"   => $istTime
        );
        
        $sql   = queryMaker("sessions", $queryDate, "Insert");
        $query = $db->prepare($sql);
        $query->execute();
        
        $db->commit();
        
        $returnData = array();
        $returnData['user_id']              = "LNUSR".$returned_id;
        $returnData['user_name']            = $returned_fullName;
        $returnData['session_id']           = "LNSESS".$sessionId;
        $returnData['access_token']         = $accessToken;
        $returnData['access_token_expiry']  = strtotime($accessTokenExpiry);
        $returnData['refresh_token']        = $refreshToken;
        $returnData['refresh_token_expiry'] = strtotime($refreshTokenExpiry);

        $response = new Response(true, 201, "Logged in Successfully", $returnData);
        $response->send();
        exit();
    
    } catch(PDOException $e) {
        
        error_log("SQL Error - Session Creation - " . $e->getMessage());
        $db->rollBack();
        $response = new Response(false, 500, "(Action:- Session) Sever Error");
        $response->send();
        exit();
        
    }
    
}

else {
    
    $response = new Response(false, 405, "Invalid Method");
    $response->send();
    exit();
    
}


?>