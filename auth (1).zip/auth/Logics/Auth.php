<?php

if(!isset($_SERVER['HTTP_AUTHORIZATION']) || strlen($_SERVER['HTTP_AUTHORIZATION']) < 1) {
    
    $response = new Response(false, 401, "Unauthorized Error");
    $response->send();
    exit();
    
}

$accessToken = $_SERVER['HTTP_AUTHORIZATION'];

$userId      = explode("_", manualDecryption($accessToken))[0];

try {

    $query = $db->prepare("SELECT * FROM `sessions` s INNER JOIN users u ON s.user_id=u.user_id WHERE `session_id`='$sessionId' AND u.`user_id`='$userId' AND `session_active`='Y'");
    $query->execute();
    
    $rowCount = $query->rowCount();

    if($rowCount === 0) {
        
        $response = new Response(false, 404, "No Active Sessions");
        $response->send();
        exit();
        
    }

    $row = $query->fetch(PDO::FETCH_ASSOC);

    $returned_id                 = $row['user_id'];
    $returned_fullName           = $row['user_full_name'];
    $returned_email              = $row['user_email_id'];
    $returned_otp                = $row['otp'];
    $returned_otpValidity        = $row['otp_validity'];
    $returned_loginAttempts      = $row['user_login_attempts'];
    $returned_userActive         = $row['user_active'];
    $returned_sessionId          = $row['session_id'];
    $returned_accessToken        = $row['access_token'];
    $returned_accessTokenExpiry  = strtotime($row['access_token_expiry']);
    $returned_refreshToken       = $row['refresh_token'];
    $returned_refreshTokenExpiry = strtotime($row['refresh_token_expiry']);

    if($returned_userActive !== 'Y') {
        
        $response = new Response(false, 403, "Account is Terminated");
        $response->send();
        exit();
      
    }

    if($returned_loginAttempts >= 3) {
        
        $response = new Response(false, 403, "Too Many Incorrect Passcode");
        $response->send();
        exit();
      
    }
    
    $bypassAccessTokenCheck = isset($bypassAccessTokenCheck) && $bypassAccessTokenCheck ? 1 : 0;
    
    if($returned_accessTokenExpiry < time() && !$bypassAccessTokenCheck) {
        
        $response = new Response(false, 408, "Something Went Wrong. Refresh Page");
        $response->send();
        exit();
        
    }

} catch(PDOException $e) {
        
    error_log("SQL Error - Authentication - " . $e->getMessage());
    $response = new Response(false, 500, "(Action:- Authentication) Sever Error");
    $response->send();
    exit();

}

?>