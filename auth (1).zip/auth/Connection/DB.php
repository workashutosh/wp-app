<?php

//Headers for CORS
if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}


require_once($_SERVER['DOCUMENT_ROOT'] . '/Model/Response.php');

date_default_timezone_set('Asia/Calcutta');

$istTime = date('Y-m-d H:i:s');

class DB {
    
    private static $con;
    
    public static function connectDB() {
        
        if(self::$con === null) {
            
            self::$con = new PDO("mysql:host=localhost;dbname=aarnainw_finance_prod_copy", 'aarnainw_ashutosh', '4PtX8dn]&m!-');
            
            //set the PDO error mode to exception
            self::$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
        }
        
        return self::$con;
        
    }
    
}

try {
    
    $db = DB::connectDB();
    
} catch(PDOException $e) {
    
    error_log("DB Connection Error - " . $e->getMessage(), 0);
    
    //DB Failure Response and Exit
    $response = new Response(false, 500, "Connection Error");
    $response->send();
    exit();
  
}