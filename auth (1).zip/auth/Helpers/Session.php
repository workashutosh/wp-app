<?php

if($_SERVER['CONTENT_TYPE'] !== 'application/json') {
    
    $response = new Response(false, 406, "Content-Type Error");
    $response->send();
    exit();
    
}

$rawData = file_get_contents('php://input');

if(!$jsonData = json_decode($rawData)) {

    $response = new Response(false, 403, "Data Forbidden");
    $response->send();
    exit();
    
}

if(!isset($jsonData->session_id) || strlen($jsonData->session_id) < 1)  {
    
    $response = new Response(false, 401, "Unauthorized Error");
    $response->send();
    exit();
    
}

$sessionId = $jsonData->session_id;
$sessionId = str_replace("LNSESS", "", $sessionId);

?>