<?php 

class Lead {

	private $lid;
	private $lname;
	private $lnumber;
	private $lshow;
	private $lstatus;
	private $remarks;
	private $fu;
	private $reqnquire;
	private $rdate;
	private $created;
  
	public function __construct($lid, $lname, $lnumber, $lshow, $lstatus, $remarks, $fu, $reqnquire, $rdate, $created) {
		$this->lid = $lid;
		$this->lname = $lname;
		$this->lnumber = $lnumber;
		$this->show = $lshow;
		$this->lstatus = $lstatus;
		$this->remarks = $remarks;
		$this->fu = $fu;
		$this->reqnquire = $reqnquire;
		$this->rdate = $rdate;
		$this->created = $created;
	}
  
  	public function returnLeadArr() {
		$lead = array();
		$lead['id'] = $this->lid;
		$lead['name'] = $this->lname;
		$lead['number'] = $this->lnumber;
		$lead['show'] = $this->show;
		$lead['status'] = $this->lstatus;
		$lead['remarks'] = $this->remarks;
		$lead['fu'] = $this->fu;
		$lead['reqnquire'] = $this->reqnquire;
		$lead['rdate'] = $this->rdate;
		$lead['created'] = $this->created;
		return $lead;
	}
  
}