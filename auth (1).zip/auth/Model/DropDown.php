<?php 

class DropDown {

	private $ddid;
	private $ddvalue;
	private $ddchoosen;
	private $ddshow;
  
	public function __construct($ddid, $ddvalue, $ddchoosen, $ddshow) {
		$this->ddid      = $ddid;
		$this->ddvalue   = $ddvalue;
		$this->ddchoosen = $ddchoosen;
		$this->ddshow    = $ddshow;
	}
  
  	public function returnDDArr() {
		$dd = array();
		$dd['id']      = $this->ddid;
		$dd['value']   = $this->ddvalue;
		$dd['choosen'] = $this->ddchoosen;
		$dd['show']    = $this->ddshow;
		return $dd;
	}
  
}