<?php

class Response {
    
    private $success;
    private $httpStatusCode;
    private $messages = array();
    private $data;
    private $toCache = false;
    private $responseData = array();
    
    public function __construct($success, $httpStatusCode, $message, $data = null, $toCache = false) {
		$this->success        = $success;
		$this->httpStatusCode = $httpStatusCode;
		$this->messages[]     = $message;
		$this->data           = $data;
		$this->toCache        = $toCache;
	}
    
    public function send() {
        
        //Set the return content type
        header('Content-type: application/json; charset=utf-8');
        
        //Set headers for cache control depending on whether we need to cache or not
        if($this->toCache) {
            header('Cache-control: max-age=60');
        } else {
            header('Cache-control: no-cache, no-store');
        }
        
        //return the data in json format based on below conditions
        if(!is_bool($this->success) || !is_numeric($this->httpStatusCode)) {
            
            http_response_code(500);
            $this->responseData['success']    = false;
            $this->responseData['statusCode'] = 500;
            $this->addMessage('Error...');
            $this->responseData['messages']   = $this->messages;
            
        } else {
            
            http_response_code($this->httpStatusCode);
            $this->responseData['success']    = $this->success;
            $this->responseData['statusCode'] = $this->httpStatusCode;
            $this->responseData['messages']   = $this->messages;
            $this->responseData['data']       = $this->data;
            
        }
        
        echo json_encode($this->responseData);
        
    }
    
}